Extending ncclient
==================

**TODO**

Here it is discussed how new transport mappings and new operations can be added.

